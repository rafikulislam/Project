        <footer>
            <section id="ftr-up">
                <div class="container ftr-bg">
                    <div class="row">
                        <div class="col-md-2 col-sm-2 heading">
                            <h3>Information</h3>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Products</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Terms & Conditions</a></li>
                            </ul>
                        </div>
                        <div class="col-md-2 col-sm-2 heading">
                            <h3>Extras</h3>
                            <ul>
                                <li><a href="#">Brands</a></li>
                                <li><a href="#">Gift Vouchers</a></li>
                                <li><a href="#">Affiliates</a></li>
                                <li><a href="#">Specials</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-sm-3 heading">
                            <h3>Contact Us</h3>
                            <ul>
                                <li><a href="#">Phone : +88 02 883 5550</a></li>
                                <li><a href="#">FAX : +88 02 882 0256</a></li>
                                <li><a href="#">E-mail : rma@system.com</a></li>
                            </ul>
                        </div>
                        <div class="col-md-3 col-sm-3 heading">
                            <h3>Customer Service</h3>
                            <ul>
                                <li><a href="#">Contact Us</a></li>
                                <li><a href="#">Returns</a></li>
                                <li><a href="#">Site Map</a></li>
                            </ul>
                        </div>
                        <div class="col-md-2 col-sm-2 heading">
                            <h3>Follow us</h3>
                            <ul class="ftr-social">
                                <li>
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>
            <section id="ftr-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 p0">
                            <p>&copy; 2017 RAFIKUL ISLAM RAFI. All Rights Reserved.</p>
                        </div>
                    </div>
                </div>
            </section><!--  ends -->
        </footer>
    </body>
</html>
        
  
