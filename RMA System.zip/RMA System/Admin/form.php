<?php
	require_once('function/function.php');
	get_part('header.php');
	get_part('sidebar.php');
	get_part('bread.php');
	get_part('form_page.php');
	get_part('footer.php');
?>