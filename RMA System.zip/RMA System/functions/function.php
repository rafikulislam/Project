<?php
	require_once('config.php');
	function get_part($addpart){
		include_once('includes/'.$addpart);
		}
              
               
?>